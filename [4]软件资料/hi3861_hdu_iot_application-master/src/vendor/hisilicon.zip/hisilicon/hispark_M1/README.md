

本目录下：

1.HiSpark_M1十分钟上手.md：快速搭建环境

2.demo案列：

| 例程名              | 功能                                             | 文档章节 |
| ------------------- | ------------------------------------------------ | -------- |
| helloworld_demo     | 屏幕显示helloword字样，LED灯闪烁，检验环境和初学 | 2.9      |
| interrupt_demo      | 中断实验                                         | 4.1      |
| rotation_demo       | 无级调光                                         | 4.2      |
| matrixkeyboard_demo | 矩阵键盘                                         | 4.3      |
| rtc_demo            | 万年历                                           | 4.4      |
| traffic_light_demo  | 交通灯                                           | 4.5      |
| i2s_voice_demo      | 录音播放                                         | 4.6      |
| nfc_demo            | 手机与NFC通信                                    | 4.7      |
| spi_gyro_demo       | 显示航向角，俯仰角，滚动角                       | 4.9      |
| environment_demo    | 监测温湿度                                       | 4.8      |
| histreaming_demo    | 手机控制LED灯                                    | 4.10     |

3.doc：包含微处理器实验指导手册和硬件原理图